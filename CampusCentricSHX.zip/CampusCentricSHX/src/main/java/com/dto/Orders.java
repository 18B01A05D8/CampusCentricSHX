package com.dto;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@XmlRootElement

public class Orders {
	@Id
	@GeneratedValue
	private int orderId;
	private String orderStatus;
	private String orderPayment;
	
	@JsonIgnoreProperties("order")
	@OneToOne
	@JoinColumn(name="bookId")
	private Book book;
	
	@JsonIgnoreProperties("order")
	@OneToOne
	@JoinColumn(name="productId")
	private Product product;
	
	@JsonIgnoreProperties("orderList")
	@ManyToOne
	@JoinColumn(name="studentId")
	private Student student;

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public String getOrderPayment() {
		return orderPayment;
	}

	public void setOrderPayment(String orderPayment) {
		this.orderPayment = orderPayment;
	}

	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	/*@Override
	public String toString() {
		return "Orders [orderId=" + orderId + ", orderStatus=" + orderStatus + ", orderPayment=" + orderPayment
				+ ", book=" + book + ", product=" + product + ", student=" + student + "]";
	}*/
	
	

}
