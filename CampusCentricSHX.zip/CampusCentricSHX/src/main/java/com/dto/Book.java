package com.dto;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@XmlRootElement
public class Book {
	@Id
	@GeneratedValue
	private int bookId;
	private String bookName;
	private String categoryName;
	private String authorName;
	private String bookImage;
	private double bookPrice;
	private String bookStatus;
	
	
	@OneToOne(mappedBy="book",fetch = FetchType.LAZY)
	private Orders order;
	
	@JsonIgnoreProperties("bookList")
	@ManyToOne
	@JoinColumn(name="studentId")
	private Student student;

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public double getBookPrice() {
		return bookPrice;
	}

	public void setBookPrice(double bookPrice) {
		this.bookPrice = bookPrice;
	}

	public Student getStudent() {
		return student;
	}

	public void setUser(Student student) {
		this.student = student;
	}

	

	public String getBookStatus() {
		return bookStatus;
	}

	public void setBookStatus(String bookStatus) {
		this.bookStatus = bookStatus;
	}

	public void setOrder(Orders order) {
		this.order = order;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public String getBookImage() {
		return bookImage;
	}

	public void setBookImage(String bookImage) {
		this.bookImage = bookImage;
	}

	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", bookName=" + bookName + ", categoryName=" + categoryName + ", authorName="
				+ authorName + ", bookImage=" + bookImage + ", bookPrice=" + bookPrice + ", bookStatus=" + bookStatus
				+ ", order=" + order + ", student=" + student + "]";
	}
		

}
