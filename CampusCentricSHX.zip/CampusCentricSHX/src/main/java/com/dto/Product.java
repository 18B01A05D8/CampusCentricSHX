package com.dto;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@XmlRootElement
public class Product {
	@Id
	@GeneratedValue
	private int productId;
	private String productName;
	private String categoryName;
	private String productImage;
	private double productPrice;
	private String productStatus;
	
	@JsonIgnoreProperties("product")
	@OneToOne(mappedBy="product",fetch = FetchType.LAZY)
	Orders order = new Orders();
	
	@JsonIgnoreProperties("productList")
	@ManyToOne
	@JoinColumn(name="studentId")
	private Student student;

	public int getproductId() {
		return productId;
	}

	public void setproductId(int productId) {
		this.productId = productId;
	}

	public String getproductName() {
		return productName;
	}

	public void setproductName(String productName) {
		this.productName = productName;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}


	public double getproductPrice() {
		return productPrice;
	}

	public void setproductPrice(double productPrice) {
		this.productPrice = productPrice;
	}

	public Student getStudent() {
		return student;
	}

	public void setUser(Student student) {
		this.student = student;
	}

	public Orders getOrder() {
		return order;
	}

	public void setOrderdetailsList(Orders order) {
		this.order = order;
	}

	public String getproductStatus() {
		return productStatus;
	}

	public void setproductStatus(String productStatus) {
		this.productStatus = productStatus;
	}

	public void setOrder(Orders order) {
		this.order = order;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public String getproductImage() {
		return productImage;
	}

	public void setproductImage(String productImage) {
		this.productImage = productImage;
	}

	/*@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", categoryName=" + categoryName
				+ ", productImage=" + productImage + ", productPrice=" + productPrice + ", productStatus="
				+ productStatus + ", order=" + order + ", student=" + student + "]";
	}*/
	
	
}
