package com.dto;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@XmlRootElement
public class Student {
	@Id
	@GeneratedValue
	
	private int studentId;
	private String sName;
	private String mobile;
	// @Column(unique = true)
	private String emailId;
	private String password;
	private String qrScan;
	
	@JsonIgnoreProperties("student")
	@OneToMany(mappedBy="student",fetch = FetchType.LAZY)
	List<Book> bookList = new ArrayList<Book>();
	
	@JsonIgnoreProperties("student")
	@OneToMany(mappedBy="student",fetch = FetchType.LAZY)
	List<Orders> orderList = new ArrayList<Orders>();

	@JsonIgnoreProperties("student")
	@OneToMany(mappedBy="student",fetch = FetchType.LAZY)
	List<Product> productList = new ArrayList<Product>();
	
	@JsonIgnoreProperties("student")
	@OneToMany(mappedBy="student",fetch = FetchType.LAZY)
	List<Feedback> feedback = new ArrayList<Feedback>();

	

	public List<Product> getProductList() {
		return productList;
	}

	public void setProductList(List<Product> productList) {
		this.productList = productList;
	}

	public List<Feedback> getFeedback() {
		return feedback;
	}

	public void setFeedback(List<Feedback> feedback) {
		this.feedback = feedback;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public List<Book> getBookList() {
		return bookList;
	}
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getsName() {
		return sName;
	}

	public void setsName(String sName) {
		this.sName = sName;
	}

	public String getQrScan() {
		return qrScan;
	}

	public void setQrScan(String qrScan) {
		this.qrScan = qrScan;
	}

	public void setBookList(List<Book> bookList) {
		this.bookList = bookList;
	}

	public List<Orders> getOrderList() {
		return orderList;
	}

	public void setOrderList(List<Orders> orderList) {
		this.orderList = orderList;
	}

/*	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", sName=" + sName + ", mobile=" + mobile + ", emailId=" + emailId
				+ ", password=" + password + ", qrScan=" + qrScan + ", bookList=" + bookList + ", orderList="
				+ orderList + ", productList=" + productList + "]";
	}*/
	
	
}
