package com.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.sql.Blob;
@Entity
@XmlRootElement
public class Feedback {
	@Id
	@GeneratedValue
	private int fId;
	private int rating;
	private Blob fdesc;
	
	@JsonIgnoreProperties("feedback")
	@ManyToOne
	@JoinColumn(name="studentId")
	private Student student;


	public int getfId() {
		return fId;
	}

	public void setfId(int fId) {
		this.fId = fId;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public Blob getFdesc() {
		return fdesc;
	}

	public void setFdesc(Blob fdesc) {
		this.fdesc = fdesc;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	@Override
	public String toString() {
		return "Feedback [fId=" + fId + ", rating=" + rating + ", fdesc=" + fdesc + ", student=" + student + "]";
	}

	
}
