package com.db;

import java.io.Serializable;


import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

import com.dto.Book;
import com.dto.Student;

public class HibernateTemplate {
	
private static SessionFactory sessionFactory;
	
	static {
		sessionFactory=new Configuration().configure().buildSessionFactory();
	}
	
	public static int addObject(Object obj)
	{
		System.out.println("Inside Template...");
		int result=0;
		
		Transaction tx=null;
		
		try {
			
			Session session=sessionFactory.openSession();
			tx=session.beginTransaction();
			
			session.save(obj);
			
			tx.commit();
			
			result=1;
			
		} catch (Exception e) {
		
			tx.rollback();
			
			e.printStackTrace();
		}
		
		return result;
	}
	
	public static Object getObject(Class c,Serializable serializable)
	{
		Object obj=null;
		
		try {			
			return sessionFactory.openSession().get(c,serializable);
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
		return obj;
	}
	
	/*public static Object getObjectByUserPass(String loginId,String password) {
	
	String queryString = "from User where emailId = :loginId and password =:password";
	  Query query = sessionFactory.openSession().createQuery(queryString);
	  query.setString("loginId", loginId);
	  query.setString("password", password);
	  Object queryResult = query.uniqueResult();
	  User user = (User)queryResult;
	  return user; 
	}*/
	
	public static Object getObjectByEmail(String emailId) {
		
		String queryString = "from Student where emailId = :emailId";
		  Query query = sessionFactory.openSession().createQuery(queryString);
		  query.setString("emailId", emailId);
		  Object queryResult = query.uniqueResult();
		  Student student = (Student)queryResult;
		  return student; 
	}
	
	public static List<Object> viewOrderById(int studentId) {
		
		String queryString = "from Orders where studentId = :studentId";
		  Query query = sessionFactory.openSession().createQuery(queryString);
		  query.setInteger("studentId", studentId);
		  Object queryResult = query.list();
		  List<Object> orders = (List)queryResult;
		  return orders; 
		}
public static List<Object> getBooks(String bookStatus, int studentId) {
		
		String queryString = "from Book where bookStatus = :bookStatus and studentId != :studentId";
		  Query query = sessionFactory.openSession().createQuery(queryString);
		  query.setString("bookStatus", bookStatus);
		  query.setInteger("studentId", studentId);
		  Object queryResult = query.list();
		  List<Object> books = (List)queryResult;
		  return books; 
		}
public static List<Object> getBookById(int studentId) {
	
	String queryString = "from Book where studentId = :studentId";
	  Query query = sessionFactory.openSession().createQuery(queryString);
	  query.setInteger("studentId", studentId);
	  Object queryResult = query.list();
	  List<Object> books = (List)queryResult;
	  return books; 
	}
public static List<Object> getProductById(int studentId) {
	
	String queryString = "from Product where studentId = :studentId";
	  Query query = sessionFactory.openSession().createQuery(queryString);
	  query.setInteger("studentId", studentId);
	  Object queryResult = query.list();
	  List<Object> products = (List)queryResult;
	  return products; 
	}
public static List<Object> getProductByName(String productName, int studentId, String productStatus) {
	
	String queryString = "from Product where studentId != :studentId and productName = :productName and productStatus = :productStatus";
	  Query query = sessionFactory.openSession().createQuery(queryString);
	  query.setInteger("studentId", studentId);
	  query.setString("productName", productName);
	  query.setString("productStatus", productStatus);
	  Object queryResult = query.list();
	  List<Object> products = (List)queryResult;
	  return products; 
	}
public static List<Object> getBookByName(String bookName, int studentId, String bookStatus) {
	
	String queryString = "from Book where studentId != :studentId and bookName = :bookName and bookStatus = :bookStatus";
	  Query query = sessionFactory.openSession().createQuery(queryString);
	  query.setInteger("studentId", studentId);
	  query.setString("bookName", bookName);
	  query.setString("bookStatus", bookStatus);
	  Object queryResult = query.list();
	  List<Object> books = (List)queryResult;
	  return books; 
	}
public static int updateBook(int bookId, String bookStatus) {
	// TODO Auto-generated method stub
	System.out.println("Book Updated");
	Session session=sessionFactory.openSession();
	org.hibernate.Transaction tx= null;
	tx = session.beginTransaction();
	org.hibernate.Query q=session.createQuery("update Book set bookStatus=:bookStatus where bookId=:bookId");
	q.setParameter("bookStatus",bookStatus);
	q.setParameter("bookId",bookId);

	int status=q.executeUpdate();
	System.out.println(status);
	tx.commit();
	return status;
}
public static int updateEmail(int studentId, String emailId) {
	// TODO Auto-generated method stub
	Session session=sessionFactory.openSession();
	org.hibernate.Transaction tx= null;
	tx = session.beginTransaction();
	org.hibernate.Query q=session.createQuery("update Student set emailId=:emailId where studentId=:studentId");
	q.setParameter("emailId",emailId);
	q.setParameter("studentId",studentId);

	int status=q.executeUpdate();
	System.out.println(status);
	tx.commit();
	return status;
}
public static int updatePassword(String emailId, String password) {
	// TODO Auto-generated method stub
	Session session=sessionFactory.openSession();
	org.hibernate.Transaction tx= null;
	tx = session.beginTransaction();
	org.hibernate.Query q=session.createQuery("update Student set password=:password where emailId=:emailId");
	q.setParameter("password",password);
	q.setParameter("emailId",emailId);

	int status=q.executeUpdate();
	System.out.println(status);
	tx.commit();
	return status;
}
public static int updateName(int studentId, String sName) {
	// TODO Auto-generated method stub
	Session session=sessionFactory.openSession();
	org.hibernate.Transaction tx= null;
	tx = session.beginTransaction();
	org.hibernate.Query q=session.createQuery("update Student set sName=:sName where studentId=:studentId");
	q.setParameter("sName",sName);
	q.setParameter("studentId",studentId);

	int status=q.executeUpdate();
	System.out.println(status);
	tx.commit();
	return status;
}
public static int updateMobile(int studentId, String mobile) {
	// TODO Auto-generated method stub
	Session session=sessionFactory.openSession();
	org.hibernate.Transaction tx= null;
	tx = session.beginTransaction();
	org.hibernate.Query q=session.createQuery("update Student set mobile=:mobile where studentId=:studentId");
	q.setParameter("mobile",mobile);
	q.setParameter("studentId",studentId);

	int status=q.executeUpdate();
	System.out.println(status);
	tx.commit();
	return status;
}
public static int updateProduct(int productId, String productStatus) {
	// TODO Auto-generated method stub
	System.out.println("Product Updated");
	Session session=sessionFactory.openSession();
	org.hibernate.Transaction tx= null;
	tx = session.beginTransaction();
	org.hibernate.Query q=session.createQuery("update Product set productStatus=:productStatus where productId=:productId");
	q.setParameter("productStatus",productStatus);
	q.setParameter("productId",productId);

	int status=q.executeUpdate();
	System.out.println(status);
	tx.commit();
	return status;
}
public static List<Object> getProduct(String productStatus, String categoryName, int studentId) {
	String queryString = "from Product where productStatus = :productStatus and categoryName = :categoryName and studentId != :studentId";
	  Query query = sessionFactory.openSession().createQuery(queryString);
	  query.setString("productStatus", productStatus);
	  query.setString("categoryName", categoryName);
	  query.setInteger("studentId", studentId);
	  Object queryResult = query.list();
	  List<Object> products = (List)queryResult;
	  return products; 
	}
public static List<Object> getBookByCategoryName(String categoryName, int studentId, String bookStatus) {
	String queryString = "from Book where bookStatus = :bookStatus and categoryName = :categoryName and studentId != :studentId";
	  Query query = sessionFactory.openSession().createQuery(queryString);
	  query.setString("bookStatus", bookStatus);
	  query.setString("categoryName", categoryName);
	  query.setInteger("studentId", studentId);
	  Object queryResult = query.list();
	  List<Object> books = (List)queryResult;
	  return books; 
	}
public static List<Object> searchBook(String bookName, int studentId, String bookStatus) {
	String queryString = "from Book where bookStatus = :bookStatus and bookName like :bookName and studentId != :studentId";
	  Query query = sessionFactory.openSession().createQuery(queryString);
	  query.setString("bookStatus", bookStatus);
	  query.setString("bookName", "%" + bookName + "%");
	  query.setInteger("studentId", studentId);
	  Object queryResult = query.list();
	  List<Object> books = (List)queryResult;
	  return books; 
	}
public static List<Object> searchProduct(String productName, int studentId, String productStatus) {
	String queryString = "from Product where productStatus = :productStatus and productName like :productName and studentId != :studentId";
	  Query query = sessionFactory.openSession().createQuery(queryString);
	  query.setString("productStatus", productStatus);
	  query.setString("productName", "%" + productName + "%");
	  query.setInteger("studentId", studentId);
	  Object queryResult = query.list();
	  List<Object> products = (List)queryResult;
	  return products; 
	}

public static Book getBookbyBookId(int bookId) {
	String queryString = "from Book where bookId = :bookId";
	  Query query = sessionFactory.openSession().createQuery(queryString);
	  query.setInteger("bookId", bookId);
	  Object queryResult = query.uniqueResult();
	  Book book = (Book)queryResult;
	  return book; 
	
}
public static List<String> getCategory() {
	//Query qry = sessionFactory.openSession().createQuery("from Book b");
	String queryString = "select distinct b.categoryName from Book b";
	  Query query = sessionFactory.openSession().createQuery(queryString);
	  Object queryResult = query.list();
	  List<String> categories = (List)queryResult;
	  return categories;
	
}
public static List<String> getMails() {
	//Query qry = sessionFactory.openSession().createQuery("from Book b");
	String queryString = "select distinct s.emailId from Student s";
	  Query query = sessionFactory.openSession().createQuery(queryString);
	  Object queryResult = query.list();
	  List<String> mails = (List)queryResult;
	  return mails;
	
}

	public static List<Object> getObjectListByQuery(String query)
	{
		return sessionFactory.openSession().createQuery(query).list();
	}
	
	public static int updateObject(Object obj)
	{
		int result=0;
		
		Transaction tx=null;
		
		try {
			
			Session session=sessionFactory.openSession();
			tx=session.beginTransaction();
			
			session.saveOrUpdate(obj);
			
			tx.commit();
			
			result=1;
			
		} catch (Exception e) {
		
			tx.rollback();
			
			e.printStackTrace();
		}
		
		return result;
	}
	
	public static int deleteObject(Class c,Serializable serializable)
	{
		int result=0;
		
		Session session=sessionFactory.openSession();
		
		Transaction tx=session.beginTransaction();
		
		try {
			
			Object obj=session.get(c,serializable);
			
			session.delete(obj);
			
			tx.commit();
			
			result=1;
						
		} catch (Exception e) {
			
			e.printStackTrace();
			
			tx.rollback();
		}
		
		return result;
	}

	public static List<Object> getObjectListByName(Class c, String columName, String value) {
		Session session=sessionFactory.openSession();
		  Criteria criteria = session.createCriteria(c);
			Criterion nameCriterion = Restrictions.eq(columName, value);
			criteria.add(nameCriterion);
			return criteria.list();
	}
	
	
	
	/*public static List<Object> getObjectListById(Class c, String columName, User value) {
		Session session=sessionFactory.openSession();
		  Criteria criteria = session.createCriteria(c);
			Criterion nameCriterion = Restrictions.eq(columName, value);
			criteria.add(nameCriterion);
			return criteria.list();
	}*/

}

