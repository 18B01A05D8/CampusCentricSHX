package com.dao;

import java.util.List;

import org.hibernate.SessionFactory;

import com.db.HibernateTemplate;
import com.dto.Book;

public class BookDAO {
private SessionFactory factory = null;
	
	public int register(Book book) {		
		return HibernateTemplate.addObject(book);
	}
	public List<Book> getAllBooks(String bookStatus, int studentId) {
		List<Book> books=(List)HibernateTemplate.getBooks(bookStatus, studentId);
		return books;	
	}
	public Book getBookbyBookId(int bookId) {
		return HibernateTemplate.getBookbyBookId(bookId);
	}
	public List<Book> getBookById(int studentId) {
		return (List)HibernateTemplate.getBookById(studentId);
	}
	public List<Book> getBookByName(String bookName, int studentId, String bookStatus) {	
		return (List)HibernateTemplate.getBookByName(bookName, studentId, bookStatus);
	}
	public List<Book> getBookByCategoryName(String categoryName, int studentId,String bookStatus) {	
		return (List)HibernateTemplate.getBookByCategoryName(categoryName, studentId, bookStatus);
	}
	public List<String> getCategory() {
		return (List)HibernateTemplate.getCategory();
	}
	public int updateBook(int bookId, String bookStatus){
		 return HibernateTemplate.updateBook(bookId,bookStatus);
	}
	public List<Book> searchBook(String bookName, int studentId,String bookStatus) {	
		return (List)HibernateTemplate.searchBook(bookName, studentId, bookStatus);
	}
	

}
