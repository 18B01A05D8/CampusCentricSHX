package com.dao;

import java.util.List;

import org.hibernate.SessionFactory;

import com.db.HibernateTemplate;
import com.dto.Book;

public class BookDAO {
private SessionFactory factory = null;
	
	public int register(Book book) {		
		return HibernateTemplate.addObject(book);
	}
	public List<Book> getAllBooks(String bookStatus) {
		List<Book> books=(List)HibernateTemplate.getBooks(bookStatus);
		return books;	
	}

}
