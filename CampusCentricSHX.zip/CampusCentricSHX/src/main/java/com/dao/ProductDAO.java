package com.dao;

import java.util.List;

import org.hibernate.SessionFactory;

import com.db.HibernateTemplate;
import com.dto.Product;

public class ProductDAO {
private SessionFactory factory = null;
	
	public int register(Product product) {		
		return HibernateTemplate.addObject(product);
	}

	public List<Product> getAllElectronic(String productStatus, String categoryName, int studentId) {
		List<Product> products=(List)HibernateTemplate.getProduct(productStatus, categoryName, studentId);
		return products;	
	}
	public List<Product> getAllDaily(String productStatus, String categoryName, int studentId) {
		List<Product> products=(List)HibernateTemplate.getProduct(productStatus, categoryName, studentId);
		return products;	
	}
	public List<Product> getProductByName(String productName, int studentId, String productStatus) {	
		return (List)HibernateTemplate.getProductByName(productName,studentId,productStatus);
	}
	
	public List<Product> getProductById(int studentId) {
		return (List)HibernateTemplate.getProductById(studentId);
	}
	public int updateProduct(int productId, String productStatus){
		 return HibernateTemplate.updateProduct(productId,productStatus);
	}
	public List<Product> searchProduct(String productName, int studentId,String productStatus) {	
		return (List)HibernateTemplate.searchProduct(productName, studentId, productStatus);
	}
}
