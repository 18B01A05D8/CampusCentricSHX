package com.dao;

import java.util.List;

import org.hibernate.SessionFactory;

import com.db.HibernateTemplate;
import com.dto.Book;
import com.dto.Product;

public class ProductDAO {
private SessionFactory factory = null;
	
	public int register(Product product) {		
		return HibernateTemplate.addObject(product);
	}

	public List<Product> getAllElectronic(String productStatus, String categoryName) {
		List<Product> products=(List)HibernateTemplate.getProduct(productStatus, categoryName);
		return products;	
	}
	public List<Product> getAllDaily(String productStatus, String categoryName) {
		List<Product> products=(List)HibernateTemplate.getProduct(productStatus, categoryName);
		return products;	
	}
}
