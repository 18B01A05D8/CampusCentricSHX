package com.dao;

import java.util.List;

import org.hibernate.SessionFactory;

import com.db.HibernateTemplate;
import com.dto.Student;

public class StudentDAO {
	private SessionFactory factory = null;

	public int register(Student student) {
		System.out.println(student); 
		return HibernateTemplate.addObject(student);
	}
	public Student getStudentByEmail(String emailId) {
		return (Student)HibernateTemplate.getObjectByEmail(emailId);
	}

	public Student getStudent(int id) {
		return (Student)HibernateTemplate.getObject(Student.class,id);
	}
	public int updateStudent(Student student){
		 return HibernateTemplate.updateObject(student);
	}
	public int updateEmail(int studentId, String emailId){
		 return HibernateTemplate.updateEmail(studentId, emailId);
	}
	public int updateMobile(int studentId, String mobile){
		 return HibernateTemplate.updateMobile(studentId, mobile);
	}
	public int updateName(int studentId, String sName){
		 return HibernateTemplate.updateName(studentId, sName);
	}
	public int updatePassword(String emailId, String password){
		 return HibernateTemplate.updatePassword(emailId, password);
	}
	public List<String> getMails() {
		return (List)HibernateTemplate.getMails();
	}
}
