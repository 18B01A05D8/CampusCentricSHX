package com.dao;

import org.hibernate.SessionFactory;

import com.db.HibernateTemplate;
import com.dto.Student;

public class StudentDAO {
	private SessionFactory factory = null;

	public int register(Student student) {
		System.out.println(student); 
		return HibernateTemplate.addObject(student);
	}
	public Student getStudentByEmail(String emailId) {
		return (Student)HibernateTemplate.getObjectByEmail(emailId);
	}

}
