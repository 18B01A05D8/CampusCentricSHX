package com.dao;

import java.util.List;

import com.db.HibernateTemplate;
import com.dto.Feedback;

public class FeedbackDAO {
	public int register(Feedback feedback) {		
		return HibernateTemplate.addObject(feedback);
	}
	public List<Feedback> getAllFeedback() {
		List<Feedback> feedback=(List)HibernateTemplate.getObjectListByQuery("From Feedback");
		return feedback;	
	}

}
