package com.dao;

import java.util.List;
import com.db.HibernateTemplate;
import com.dto.Orders;

public class OrdersDAO {
	public int register(Orders order) {		
		return HibernateTemplate.addObject(order);
	}
	public List<Orders> viewOrder(int studentId) {
		return (List)HibernateTemplate.viewOrderById(studentId);
	}

}
