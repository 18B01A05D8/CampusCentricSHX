package com.ts;

import java.io.File;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.sql.Blob;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;

import com.dao.BookDAO;
import com.dao.OrdersDAO;
import com.dao.StudentDAO;
import com.dao.FeedbackDAO;
import com.dto.Book;
import com.dto.Orders;
import com.dto.Student;
//import com.mysql.cj.jdbc.Blob;
import com.dao.ProductDAO;
import com.dto.Product;
import com.dto.Feedback;
/**
 * Root resource (exposed at "myresource" path)
 */
@Path("myresource")
public class MyResource {

    /**
     * Method handling HTTP GET requests. The returned object will be sent
     * to the client as "text/plain" media type.
     *
     * @return String that will be returned as a text/plain response.
     */
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String getIt() {
        return "Got it!";
    }
    @Path("hi")
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String hi() throws UnsupportedEncodingException {
		System.out.println("Hi...");
		return "Hi Service!";
	}
    
    @Path("getStudentByEmail/{emailId}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Student getStudentByEmail(@PathParam("emailId") String emailId) {
		System.out.println("Recieved path params: "+emailId); 
		StudentDAO studentDAO = new StudentDAO();
		Student student = studentDAO.getStudentByEmail(emailId);
		return student;
	}
    
    @Path("getStudent/{studentId}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Student getStudent(@PathParam("studentId") int studentId) {

		StudentDAO studentDAO = new StudentDAO();
		Student student = studentDAO.getStudent(studentId);

		return student;
	}
    @Path("mail/{emailId}/{subject}/{body}")
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String mail(@PathParam("emailId") String emailId,@PathParam("subject") String subject1,@PathParam("body") String body1) throws MessagingException {
			String subject= subject1;
			String body= body1;
			String email= emailId;
			String host = "smtp.gmail.com";
			String from = "tejaswit0708@gmail.com";
			String pass = "lakshmanaraoroopa";

			Properties props = System.getProperties();

			props.put("mail.smtp.starttls.enable", "true"); // added this line
			props.put("mail.smtp.host", host);
			props.put("mail.smtp.student", from);
			props.put("mail.smtp.password", pass);
			props.put("mail.smtp.port", "587");
			props.put("mail.smtp.auth", "true");

			String[] to = {email}; // added this line

			Session session = Session.getDefaultInstance(props, null);
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));

			InternetAddress[] toAddress = new InternetAddress[to.length];

			// To get the array of addresses

			for( int i=0; i < to.length; i++ )
			{
				// changed from a while loop
				toAddress[i] = new InternetAddress(to[i]);
			}

			for( int i=0; i < toAddress.length; i++)
			{
				// changed from a while loop
				message.addRecipient(Message.RecipientType.TO, toAddress[i]);
			}

			message.setSubject(subject);
			message.setText(body);

			Transport transport = session.getTransport("smtp");

			transport.connect(host, from, pass);
			transport.sendMessage(message, message.getAllRecipients());

			transport.close();

			return "Successful";
    	}
	
    @Path("registerStudent")
	@POST
	@Consumes({MediaType.MULTIPART_FORM_DATA})
	public void registerStudent(@FormDataParam("qrScan") InputStream fileInputStream, @FormDataParam("qrScan") FormDataContentDisposition
			formDataConnectionDisposition, @FormDataParam("sName") String sName,
			@FormDataParam("mobile") String mobile,
			@FormDataParam("emailId") String emailId,
			@FormDataParam("password") String password) throws IOException{
			int read = 0;
			byte[] bytes = new byte[1024];
			
			String path = this.getClass().getClassLoader().getResource("").getPath();
			String pathArr[] = path.split("/WEB-INF/classes/"); 
			FileOutputStream out = new FileOutputStream(new File(pathArr[0]+"/Image/",formDataConnectionDisposition.getFileName()));
			
			while((read = fileInputStream.read(bytes))!= -1){
				out.write(bytes,0,read);
			}
			out.flush();
			out.close();
			Student student = new Student();
			student.setsName(sName);
			student.setMobile(mobile);
			student.setEmailId(emailId);
			student.setQrScan(formDataConnectionDisposition.getFileName());
			student.setPassword(password);
			System.out.println(student);
			
			
			StudentDAO studentDao = new StudentDAO();
			studentDao.register(student);
	}
    
    @Path("registerStudent1")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public void registerStudent1(Student student) {
		System.out.println("Data Recieved in Student Register : " + student);
		StudentDAO studentDao = new StudentDAO();
		studentDao.register(student);
	
	}
	
	@Path("registerBook")
	@POST
	@Consumes({MediaType.MULTIPART_FORM_DATA})
	public void registerBook(@FormDataParam("bookImage") InputStream fileInputStream, @FormDataParam("bookImage") FormDataContentDisposition
			formDataConnectionDisposition, @FormDataParam("bookName") String bookName,
			@FormDataParam("authorName") String authorName,
			@FormDataParam("bookPrice") Double bookPrice,
			@FormDataParam("categoryName") String categoryName,
			@FormDataParam("studentId") Integer studentId) throws IOException{
			int read = 0;
			byte[] bytes = new byte[1024];
			
			String path = this.getClass().getClassLoader().getResource("").getPath();
			String pathArr[] = path.split("/WEB-INF/classes/"); 
			FileOutputStream out = new FileOutputStream(new File(pathArr[0]+"/Image/",formDataConnectionDisposition.getFileName()));
			
			while((read = fileInputStream.read(bytes))!= -1){
				out.write(bytes,0,read);
			}
			out.flush();
			out.close();
			System.out.println(studentId);
			Student student = new Student();
			student.setStudentId(studentId);
			Book book = new Book();
			book.setBookName(bookName);
			book.setCategoryName(categoryName);
			book.setAuthorName(authorName);
			book.setBookImage(formDataConnectionDisposition.getFileName());
			book.setBookPrice(bookPrice);
			book.setStudent(student);
			book.setBookStatus("Available");
			System.out.println(student);
			
			
			BookDAO bookDao = new BookDAO();
			bookDao.register(book);
	}

	@Path("registerProduct")
	@POST
	@Consumes({MediaType.MULTIPART_FORM_DATA})
	public void registerProduct(@FormDataParam("productImage") InputStream fileInputStream, @FormDataParam("productImage") FormDataContentDisposition
			formDataConnectionDisposition, @FormDataParam("productName") String productName,
			@FormDataParam("productPrice") Double productPrice,
			@FormDataParam("categoryName") String categoryName,
			@FormDataParam("studentId") Integer studentId) throws IOException{
			int read = 0;
			byte[] bytes = new byte[1024];
			
			String path1 = this.getClass().getClassLoader().getResource("").getPath();
			String pathArr1[] = path1.split("/WEB-INF/classes/"); 
			FileOutputStream out1;
			
				out1 = new FileOutputStream(new File(pathArr1[0]+"/Image/",formDataConnectionDisposition.getFileName()));
			
				while((read = fileInputStream.read(bytes))!= -1){
					out1.write(bytes,0,read);
				}
				out1.flush();
				out1.close();
			
			System.out.println(studentId);
			Student student = new Student();
			student.setStudentId(studentId);
			Product product = new Product();
			product.setproductName(productName);
			product.setCategoryName(categoryName);
			product.setproductImage(formDataConnectionDisposition.getFileName());
			product.setproductPrice(productPrice);
			product.setStudent(student);
			product.setproductStatus("Available");
			System.out.println(student);
			
			ProductDAO productDao = new ProductDAO();
			productDao.register(product);
	}
	
	@Path("getBooks/{studentId}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Book> getBooks(@PathParam("studentId") int studentId) {        
		System.out.println("Inside api get books...");
		BookDAO bookDao = new BookDAO();
		List <Book> bookList = bookDao.getAllBooks("Available",studentId);
		return bookList;
	}
	
	@Path("getBookByName/{bookName}/{studentId}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Book> getBookByName(@PathParam("bookName") String bookName,
			@PathParam("studentId") int studentId) {        
		System.out.println(bookName);      
		BookDAO bookDao = new BookDAO();
		List<Book> books = bookDao.getBookByName(bookName,studentId,"Available");
		System.out.println(books); 
		return books;
	}
	
	@Path("getBookbyBookId/{bookId}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Book getBookbyBookId(@PathParam("bookId") int bookId) {        
		System.out.println(bookId);      
		BookDAO bookDao = new BookDAO();
		Book book = bookDao.getBookbyBookId(bookId);
		System.out.println(book); 
		return book;
	}
	@Path("getProductByName/{productName}/{studentId}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> getProductByName(@PathParam("productName") String productName, 
			@PathParam("studentId") int studentId) {        
		System.out.println(productName);      
		ProductDAO productDao = new ProductDAO();
		List<Product> products = productDao.getProductByName(productName, studentId, "Available");
		System.out.println(products); 
		return products;
	}
	
	@Path("getBookById/{studentId}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Book> getBookByBookId(@PathParam("studentId") int studentId) {        
		System.out.println(studentId);      
		BookDAO bookDao = new BookDAO();
		List<Book> books = bookDao.getBookById(studentId);
		System.out.println(books); 
		return books;
	}
	
	@Path("getProductById/{studentId}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> getProductByProductId(@PathParam("studentId") int studentId) {        
		System.out.println(studentId);      
		ProductDAO ProductDao = new ProductDAO();
		List<Product> Products = ProductDao.getProductById(studentId);
		System.out.println(Products); 
		return Products;
	}
	
	@Path("getBookByCategoryName/{categoryName}/{studentId}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Book> getBookByCategoryName(@PathParam("categoryName") String categoryName,
			@PathParam("studentId") int studentId) {        
		System.out.println(categoryName);      
		BookDAO bookDao = new BookDAO();
		List<Book> books = bookDao.getBookByCategoryName(categoryName, studentId, "Available");
		System.out.println(books); 
		return books;
	}
	
	@Path("searchBook/{bookName}/{studentId}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Book> searchBook(@PathParam("bookName") String bookName,
			@PathParam("studentId") int studentId) {        
		System.out.println(bookName);      
		BookDAO bookDao = new BookDAO();
		List<Book> books = bookDao.searchBook(bookName, studentId, "Available");
		System.out.println(books); 
		return books;
	}
	
	@Path("searchProduct/{productName}/{studentId}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> searchProduct(@PathParam("productName") String productName, 
			@PathParam("studentId") int studentId) {        
		System.out.println(productName);      
		ProductDAO productDao = new ProductDAO();
		List<Product> products = productDao.searchProduct(productName, studentId, "Available");
		System.out.println(products); 
		return products;
	}

	@Path("getCategory")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<String> getCategory() {              
		BookDAO bookDao = new BookDAO();
		List<String> categories = bookDao.getCategory();
		System.out.println(categories); 
		return categories;
	}	
	@Path("getMails")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<String> getMails() {              
		StudentDAO studentDao = new StudentDAO();
		List<String> mails = studentDao.getMails();
		System.out.println(mails); 
		return mails;
	}	
	
	@Path("getElectronic/{studentId}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> getElectronic(@PathParam("studentId") int studentId) {        
		System.out.println("Inside api get product...");
		ProductDAO productDao = new ProductDAO();
		List <Product> electronicList = productDao.getAllElectronic("Available", "electronicdevice", studentId);
		return electronicList;
	}
	
	@Path("getDaily/{studentId}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> getDaily(@PathParam("studentId") int studentId) {        
		System.out.println("Inside api get product...");
		ProductDAO productDao = new ProductDAO();
		List <Product> dailyList = productDao.getAllDaily("Available", "dailyuse", studentId);
		return dailyList;
	}

	@Path("updateBook/{bookId}/{bookStatus}")
	@GET
	@Consumes(MediaType.APPLICATION_JSON)
	public String updateRequestStatus(@PathParam("bookId") int bookId,
	@PathParam("bookStatus") String bookStatus) {
	System.out.println("Data Recieved in UpdateBook MYRESOURCE : " + bookStatus + bookId);
	BookDAO bookDao = new BookDAO();
	bookDao.updateBook(bookId,bookStatus);
	return "success";
	}
	@Path("updateProduct/{productId}/{productStatus}")
	@GET
	@Consumes(MediaType.APPLICATION_JSON)
	public String updateRequestStatus1(@PathParam("productId") int productId,
	@PathParam("productStatus") String productStatus) {
	System.out.println("Data Recieved in UpdateProduct MYRESOURCE : " + productStatus + productId);
	ProductDAO productDao = new ProductDAO();
	productDao.updateProduct(productId,productStatus);
	return "success";
	}
	@Path("updateEmail/{studentId}/{emailId}")
	@GET
	@Consumes(MediaType.APPLICATION_JSON)
	public String updateEmail(@PathParam("studentId") int studentId,
	@PathParam("emailId") String emailId) {
	System.out.println("Data Recieved in UpdateProduct MYRESOURCE : " + emailId + studentId);
	StudentDAO studentDao = new StudentDAO();
	studentDao.updateEmail(studentId,emailId);
	return "success";
	}
	
	@Path("updateName/{studentId}/{sName}")
	@GET
	@Consumes(MediaType.APPLICATION_JSON)
	public String updateName(@PathParam("studentId") int studentId,
	@PathParam("sName") String sName) {
	System.out.println("Data Recieved in UpdateProduct MYRESOURCE : " + sName + studentId);
	StudentDAO studentDao = new StudentDAO();
	studentDao.updateName(studentId,sName);
	return "success";
	}
	@Path("updateMobile/{studentId}/{mobile}")
	@GET
	@Consumes(MediaType.APPLICATION_JSON)
	public String updateMobile(@PathParam("studentId") int studentId,
	@PathParam("mobile") String mobile) {
	System.out.println("Data Recieved in UpdateProduct MYRESOURCE : " + mobile + studentId);
	StudentDAO studentDao = new StudentDAO();
	studentDao.updateMobile(studentId,mobile);
	return "success";
	}
	@Path("updatePassword/{emailId}/{password}")
	@GET
	@Consumes(MediaType.APPLICATION_JSON)
	public String updatePassword(@PathParam("emailId") String emailId,
	@PathParam("password") String password) {
	System.out.println("Data Recieved in UpdateProduct MYRESOURCE : " + password + emailId);
	StudentDAO studentDao = new StudentDAO();
	studentDao.updatePassword(emailId,password);
	return "success";
	}
	
	@Path("viewOrder/{studentId}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Orders> viewOrderBook(@PathParam("studentId") int studentId) {        
		System.out.println("Inside api get order...");
		OrdersDAO ordersDao = new OrdersDAO();
		List <Orders> orderlist = ordersDao.viewOrder(studentId);
		return orderlist;
	}
	@Path("updateStudent")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public void updateUser(Student student) {
		System.out.println("Data Recieved in User Update : " + student);
		StudentDAO studentDao = new StudentDAO();
		studentDao.updateStudent(student);
	
	}
	
	@Path("registerOrder")
	@POST
	@Consumes({MediaType.MULTIPART_FORM_DATA})
	public void registerOrder(@FormDataParam("bookId") Integer bookId,
			@FormDataParam("studentId") Integer studentId,
			@FormDataParam("productId") Integer productId,
			@FormDataParam("orderPayment") String orderPayment) throws IOException{
		System.out.println("Data Recieved in Oder Register :");
		Book book = new Book();
		book.setBookId(bookId);
		Product product = new Product();
		product.setproductId(productId);
		Student student = new Student();
		student.setStudentId(studentId);
		Orders order = new Orders();
		System.out.println("bookId in orders" + bookId);
		System.out.println("productId in orders" + productId);
		if(bookId != 0)
			order.setBook(book);
		order.setOrderPayment(orderPayment);
		order.setOrderStatus("Sold");
		if(productId != 0)
			order.setProduct(product);
		order.setStudent(student);
		OrdersDAO OrdersDao = new OrdersDAO();
		OrdersDao.register(order);
	
	}
	@Path("uploadFeedback")
	@POST
	@Consumes({MediaType.MULTIPART_FORM_DATA})
	public void uploadFeedback(@FormDataParam("studentId") Integer studentId,
			@FormDataParam("fdesc") String fdesc, 
			@FormDataParam("rating") int rating) throws IOException{
		System.out.println("Feedback description" + fdesc);
		Feedback feedback = new Feedback();
		Student student = new Student();
		student.setStudentId(studentId);
		feedback.setStudent(student);
		feedback.setRating(rating);
		feedback.setFdesc(fdesc);
		
		FeedbackDAO feedbackDao =  new FeedbackDAO();
		feedbackDao.register(feedback);
		
	}
	@Path("getFeedback")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Feedback> getFeedback() {        
		System.out.println("Inside api get order...");
		FeedbackDAO feedbackDao = new FeedbackDAO();
		List <Feedback> feedbacklist = feedbackDao.getAllFeedback();
		return feedbacklist;
	}
	
    /*@Path("registerStudent2")
	@GET
	public String registerStudent2() {
				
		Student student = new Student();
		student.setStudentId(1);
		student.setEmailId("t.rss.vyshnavi@gmail.com");
		student.setMobile("7981160809");
		student.setPassword("pswd");
		student.setsName("Vyshnavi");
		student.setQrScan("Offline Payment");
		
		
		StudentDAO studentDao = new StudentDAO();
		studentDao.register(student);
		
		return "Success";
	
	}*/
}
