package com.ts;

import java.io.File;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;

import com.dao.BookDAO;
import com.dao.StudentDAO;
import com.dto.Book;
import com.dto.Student;
import com.dao.ProductDAO;
import com.dto.Product;
/**
 * Root resource (exposed at "myresource" path)
 */
@Path("myresource")
public class MyResource {

    /**
     * Method handling HTTP GET requests. The returned object will be sent
     * to the client as "text/plain" media type.
     *
     * @return String that will be returned as a text/plain response.
     */
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String getIt() {
        return "Got it!";
    }
    @Path("hi")
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String hi() throws UnsupportedEncodingException {
		System.out.println("Hi...");
		return "Hi Service!";
	}
    
    @Path("getStudentByEmail/{emailId}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Student getStudentByEmail(@PathParam("emailId") String emailId) {
		System.out.println("Recieved path params: "+emailId); 
		StudentDAO studentDAO = new StudentDAO();
		Student student = studentDAO.getStudentByEmail(emailId);
		return student;
	}
    @Path("mail/{emailId}/{subject}/{body}")
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String mail(@PathParam("emailId") String emailId,@PathParam("subject") String subject1,@PathParam("body") String body1) throws MessagingException {
			String subject= subject1;
			String body= body1;
			String email= emailId;
			String host = "smtp.gmail.com";
			String from = "tejaswit0708@gmail.com";
			String pass = "lakshmanaraoroopa";

			Properties props = System.getProperties();

			props.put("mail.smtp.starttls.enable", "true"); // added this line
			props.put("mail.smtp.host", host);
			props.put("mail.smtp.student", from);
			props.put("mail.smtp.password", pass);
			props.put("mail.smtp.port", "587");
			props.put("mail.smtp.auth", "true");

			String[] to = {email}; // added this line

			Session session = Session.getDefaultInstance(props, null);
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));

			InternetAddress[] toAddress = new InternetAddress[to.length];

			// To get the array of addresses

			for( int i=0; i < to.length; i++ )
			{
				// changed from a while loop
				toAddress[i] = new InternetAddress(to[i]);
			}

			for( int i=0; i < toAddress.length; i++)
			{
				// changed from a while loop
				message.addRecipient(Message.RecipientType.TO, toAddress[i]);
			}

			message.setSubject(subject);
			message.setText(body);

			Transport transport = session.getTransport("smtp");

			transport.connect(host, from, pass);
			transport.sendMessage(message, message.getAllRecipients());

			transport.close();

			return "Successful";
    	}
	
    @Path("registerStudent")
	@POST
	@Consumes({MediaType.MULTIPART_FORM_DATA})
	public void registerStudent(@FormDataParam("qrScan") InputStream fileInputStream, @FormDataParam("qrScan") FormDataContentDisposition
			formDataConnectionDisposition, @FormDataParam("sName") String sName,
			@FormDataParam("mobile") String mobile,
			@FormDataParam("emailId") String emailId,
			@FormDataParam("password") String password) throws IOException{
			int read = 0;
			byte[] bytes = new byte[1024];
			
			String path = this.getClass().getClassLoader().getResource("").getPath();
			String pathArr[] = path.split("/WEB-INF/classes/"); 
			FileOutputStream out = new FileOutputStream(new File(pathArr[0]+"/Image/",formDataConnectionDisposition.getFileName()));
			
			while((read = fileInputStream.read(bytes))!= -1){
				out.write(bytes,0,read);
			}
			out.flush();
			out.close();
			Student student = new Student();
			student.setsName(sName);
			student.setMobile(mobile);
			student.setEmailId(emailId);
			student.setQrScan(formDataConnectionDisposition.getFileName());
			student.setPassword(password);
			System.out.println(student);
			
			
			StudentDAO studentDao = new StudentDAO();
			studentDao.register(student);
	}
    
    @Path("registerStudent1")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public void registerUser(Student student) {
		System.out.println("Data Recieved in User Register : " + student);
		StudentDAO studentDao = new StudentDAO();
		studentDao.register(student);
	
	}
	
	@Path("registerBook")
	@POST
	@Consumes({MediaType.MULTIPART_FORM_DATA})
	public void registerBook(@FormDataParam("bookImage") InputStream fileInputStream, @FormDataParam("bookImage") FormDataContentDisposition
			formDataConnectionDisposition, @FormDataParam("bookName") String bookName,
			@FormDataParam("authorName") String authorName,
			@FormDataParam("bookPrice") Double bookPrice,
			@FormDataParam("categoryName") String categoryName,
			@FormDataParam("studentId") Integer studentId) throws IOException{
			int read = 0;
			byte[] bytes = new byte[1024];
			
			String path = this.getClass().getClassLoader().getResource("").getPath();
			String pathArr[] = path.split("/WEB-INF/classes/"); 
			FileOutputStream out = new FileOutputStream(new File(pathArr[0]+"/Image/",formDataConnectionDisposition.getFileName()));
			
			while((read = fileInputStream.read(bytes))!= -1){
				out.write(bytes,0,read);
			}
			out.flush();
			out.close();
			System.out.println(studentId);
			Student student = new Student();
			student.setStudentId(studentId);
			Book book = new Book();
			book.setBookName(bookName);
			book.setCategoryName(categoryName);
			book.setAuthorName(authorName);
			book.setBookImage(formDataConnectionDisposition.getFileName());
			book.setBookPrice(bookPrice);
			book.setStudent(student);
			book.setBookStatus("Available");
			System.out.println(student);
			
			
			BookDAO bookDao = new BookDAO();
			bookDao.register(book);
	}

	@Path("registerProduct")
	@POST
	@Consumes({MediaType.MULTIPART_FORM_DATA})
	public void registerProduct(@FormDataParam("productImage") InputStream fileInputStream, @FormDataParam("productImage") FormDataContentDisposition
			formDataConnectionDisposition, @FormDataParam("productName") String productName,
			@FormDataParam("productPrice") Double productPrice,
			@FormDataParam("categoryName") String categoryName,
			@FormDataParam("studentId") Integer studentId) throws IOException{
			int read = 0;
			byte[] bytes = new byte[1024];
			
			String path1 = this.getClass().getClassLoader().getResource("").getPath();
			String pathArr1[] = path1.split("/WEB-INF/classes/"); 
			FileOutputStream out1;
			
				out1 = new FileOutputStream(new File(pathArr1[0]+"/Image1/",formDataConnectionDisposition.getFileName()));
			
				while((read = fileInputStream.read(bytes))!= -1){
					out1.write(bytes,0,read);
				}
				out1.flush();
				out1.close();
			
			System.out.println(studentId);
			Student student = new Student();
			student.setStudentId(studentId);
			Product product = new Product();
			product.setproductName(productName);
			product.setCategoryName(categoryName);
			product.setproductImage(formDataConnectionDisposition.getFileName());
			product.setproductPrice(productPrice);
			product.setStudent(student);
			product.setproductStatus("Available");
			System.out.println(student);
			
			ProductDAO productDao = new ProductDAO();
			productDao.register(product);
	}
	
	@Path("getBooks")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Book> getBooks() {        
		System.out.println("Inside api get books...");
		BookDAO bookDao = new BookDAO();
		List <Book> bookList = bookDao.getAllBooks("Available");
		return bookList;
	}
	
	@Path("getElectronic")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> getElectronic() {        
		System.out.println("Inside api get product...");
		ProductDAO productDao = new ProductDAO();
		List <Product> electronicList = productDao.getAllElectronic("Available", "electronicdevice");
		return electronicList;
	}
	
	@Path("getDaily")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> getDaily() {        
		System.out.println("Inside api get product...");
		ProductDAO productDao = new ProductDAO();
		List <Product> dailyList = productDao.getAllDaily("Available", "dailyuse");
		return dailyList;
	}

    /*@Path("registerStudent1")
	@GET
	public String registerStudent1() {
				
		Student student = new Student();
		student.setStudentId(1);
		student.setEmailId("t.rss.vyshnavi@gmail.com");
		student.setMobile("7981160809");
		student.setPassword("pswd");
		student.setsName("Vyshnavi");
		student.setQrScan("hgwbkenjmsndj");
		
		
		StudentDAO studentDao = new StudentDAO();
		studentDao.register(student);
		
		return "Success";
	
	}*/
}
