import { Component, OnInit } from '@angular/core';
import { CampusshxService } from './../campusshx.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {
  studentId:any;rating:any;fdesc:any;feedbacks:any;li:any;
  constructor(private router: Router, private toastr: ToastrService, private service:CampusshxService) { 
    this.studentId = localStorage.getItem('studentId');
    
  }

  ngOnInit(): void {
    this.service.getFeedback().subscribe( (result: any) => {console.log(result); this.feedbacks = result;})
    
  }
  counter(i: number) {
    return new Array(i);
}
  
  Selectrating(value:any) {
    this.rating = value;
  }
  submitFeedback() {
    this.service.uploadFeedback(this.fdesc, this.rating, this.studentId ).subscribe();
    this.toastr.success('Feedback recieved!!');
    this.router.navigate(['dashboard']);
  }
  
}
