import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CampusshxService {

  private isUserLogged: any;
  secretKey = "12345";
  cartItems = [];
  //bookToBeAdded: Subject<any>;
  constructor(private httpClient: HttpClient) {
    this.isUserLogged = false;
    //this.bookToBeAdded = new Subject();
   }
   setUserLoggedIn(): void { // login success
    this.isUserLogged = true;
   }
   setUserLoggedOut(): void { // logout success
    this.isUserLogged = false;
   }
   getUserLogged(): any {
     return this.isUserLogged;
   }
  getUserByEmail(student : any) {
    console.log(student);
    return this.httpClient.get('CampusCentricSHX/webapi/myresource/getStudentByEmail/'+ student.emailId);
  }
  getStudent(studentId : any) {
    return this.httpClient.get('CampusCentricSHX/webapi/myresource/getStudent/'+ studentId);
  }
  updateStudent(student:any) {
    console.log(student);
    return this.httpClient.get('CampusCentricSHX/webapi/myresource/updateStudent/' + student);

  }
  postFile(ImageForm:any,filetoUpload: File,student: any){
    const formData: FormData = new FormData();
   
    formData.append('bookName',ImageForm.bookName);
    formData.append('categoryName',ImageForm.categoryName);
    formData.append('authorName',ImageForm.authorName);
    formData.append('bookImage',filetoUpload,filetoUpload.name);
    formData.append('bookPrice',ImageForm.bookPrice);
    formData.append('studentId',student.studentId);

   console.log('Inside Service...', ImageForm.user);
   //  console.log(ImageForm.bookName);
   //  console.log(ImageForm.bookPrice);
   //  console.log(ImageForm.selltype);
   //  console.log(ImageForm.user);
   //  console.log(ImageForm);
   //  console.log(formData.get('user'));

    return this.httpClient.post('CampusCentricSHX/webapi/myresource/registerBook/',formData);
  }
  postFile1(ImageForm:any,filetoUpload: File){
    const formData: FormData = new FormData();
   
    formData.append('sName',ImageForm.sName);
    formData.append('emailId',ImageForm.emailId);
    formData.append('qrScan',filetoUpload,filetoUpload.name);
    formData.append('mobile',ImageForm.mobile);
    formData.append('password',ImageForm.password);

   console.log('Inside Service...', ImageForm.user);
   //  console.log(ImageForm.bookName);
   //  console.log(ImageForm.bookPrice);
   //  console.log(ImageForm.selltype);
   //  console.log(ImageForm.user);
   //  console.log(ImageForm);
   //  console.log(formData.get('user'));

    return this.httpClient.post('CampusCentricSHX/webapi/myresource/registerStudent/',formData);
  }
  registerStudent1(student: any) {
    console.log(student);
    return this.httpClient.post('CampusCentricSHX/webapi/myresource/registerStudent1/', student);
   }
   registerOrder(bookId : any,studentId : any, productId : any, orderPayment:any) {
    console.log('in service');
    const formData: FormData = new FormData();
    formData.append('bookId',bookId);
    formData.append('studentId',studentId);
    formData.append('productId',productId);
    formData.append('orderPayment',orderPayment);
    return this.httpClient.post('CampusCentricSHX/webapi/myresource/registerOrder/', formData);
   }
   updateBook(bookId:any, bookStatus:any) {
    return this.httpClient.get('CampusCentricSHX/webapi/myresource/updateBook/' + bookId + '/' + bookStatus);
   }
   updateProduct(productId:any, productStatus:any) {
    return this.httpClient.get('CampusCentricSHX/webapi/myresource/updateProduct/' + productId + '/' + productStatus);
   }
   updateEmail(studentId : any,emailId:any) {
    return this.httpClient.get('CampusCentricSHX/webapi/myresource/updateEmail/' + studentId + '/' + emailId);
   }
   updateName(studentId : any,sName:any) {
    return this.httpClient.get('CampusCentricSHX/webapi/myresource/updateName/' + studentId + '/' +  sName);
   }
   updateMobile(studentId : any,mobile:any) {
    return this.httpClient.get('CampusCentricSHX/webapi/myresource/updateMobile/'  + studentId + '/' + mobile);
   }
   
  postProduct(ImageForm:any,filetoUpload: File,student: any){
    const formData: FormData = new FormData();
   
    formData.append('productName',ImageForm.productName);
    formData.append('categoryName',ImageForm.categoryName);
    formData.append('productImage',filetoUpload,filetoUpload.name);
    formData.append('productPrice',ImageForm.productPrice);
    formData.append('studentId',student.studentId);

   console.log('Inside Service...', ImageForm.user);
   //  console.log(ImageForm.bookName);
   //  console.log(ImageForm.bookPrice);
   //  console.log(ImageForm.selltype);
   //  console.log(ImageForm.user);
   //  console.log(ImageForm);
   //  console.log(formData.get('user'));

    return this.httpClient.post('CampusCentricSHX/webapi/myresource/registerProduct/',formData);
  }
  getBooks(studentId:any){
    return this.httpClient.get('CampusCentricSHX/webapi/myresource/getBooks/' + studentId);
  }
  getDaily(studentId:any){
    return this.httpClient.get('CampusCentricSHX/webapi/myresource/getDaily/'+ studentId);
  }
  getElectronic(studentId:any){
    return this.httpClient.get('CampusCentricSHX/webapi/myresource/getElectronic/' + studentId);
  }
  getAllBooks(studentId: any) {
    return this.httpClient.get('CampusCentricSHX/webapi/myresource/getBookById/'+ studentId );
  }
  getAllProducts(studentId: any) {
    return this.httpClient.get('CampusCentricSHX/webapi/myresource/getProductById/'+ studentId );
  }
  mail(emailId : any,subject: any, body : any){
    return this.httpClient.get('CampusCentricSHX/webapi/myresource/mail/'+ emailId + '/' + subject + '/' + body );
  }

  getBookByName(bookName : any, studentId:any){
    return this.httpClient.get('CampusCentricSHX/webapi/myresource/getBookByName/'+ bookName + '/' + studentId);
  }

  getProductByName(productName : any, studentId : any){
    return this.httpClient.get('CampusCentricSHX/webapi/myresource/getProductByName/'+ productName + '/' + studentId);
  }
  getCategory() {
    return this.httpClient.get('CampusCentricSHX/webapi/myresource/getCategory/');
  }
  getMails() {
    return this.httpClient.get('CampusCentricSHX/webapi/myresource/getMails/');
  }
  getBookByCategoryName(categoryName : any, studentId:any) {
    return this.httpClient.get('CampusCentricSHX/webapi/myresource/getBookByCategoryName/'+ categoryName + '/' + studentId);
  }
  viewOrder(studentId : any){
    return this.httpClient.get('CampusCentricSHX/webapi/myresource/viewOrder/' + studentId);
  }
  searchProduct(productName : any, studentId : any){
    return this.httpClient.get('CampusCentricSHX/webapi/myresource/searchProduct/'+ productName + '/' + studentId);
  }
  searchBook(bookName : any, studentId:any){
    return this.httpClient.get('CampusCentricSHX/webapi/myresource/searchBook/'+ bookName + '/' + studentId);
  }
  uploadFeedback(fdesc:any, rating:any, studentId:any) {
    const formData: FormData = new FormData();
    console.log(fdesc);
    console.log(rating);
    formData.append('studentId',studentId);
    formData.append('fdesc',fdesc);
    formData.append('rating',rating);
    return this.httpClient.post('CampusCentricSHX/webapi/myresource/uploadFeedback/',formData);

  }
  getFeedback() {
    return this.httpClient.get('CampusCentricSHX/webapi/myresource/getFeedback/');
  }
  updatePassword(emailId:any, password:any) {
    return this.httpClient.get('CampusCentricSHX/webapi/myresource/updatePassword/'  + emailId + '/' + password);
  }
  

}
