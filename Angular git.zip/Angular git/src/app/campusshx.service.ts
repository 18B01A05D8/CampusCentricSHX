import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CampusshxService {

  private isUserLogged: any;
  secretKey = "12345";
  cartItems = [];
  //bookToBeAdded: Subject<any>;
  constructor(private httpClient: HttpClient) {
    this.isUserLogged = false;
    //this.bookToBeAdded = new Subject();
   }
   setUserLoggedIn(): void { // login success
    this.isUserLogged = true;
   }
   setUserLoggedOut(): void { // logout success
    this.isUserLogged = false;
   }
   getUserLogged(): any {
     return this.isUserLogged;
   }
  getUserByEmail(student : any) {
    console.log(student);
    return this.httpClient.get('CampusCentricSHX/webapi/myresource/getStudentByEmail/'+ student.emailId);
  }
  postFile(ImageForm:any,filetoUpload: File,student: any){
    const formData: FormData = new FormData();
   
    formData.append('bookName',ImageForm.bookName);
    formData.append('categoryName',ImageForm.categoryName);
    formData.append('authorName',ImageForm.authorName);
    formData.append('bookImage',filetoUpload,filetoUpload.name);
    formData.append('bookPrice',ImageForm.bookPrice);
    formData.append('studentId',student.studentId);

   console.log('Inside Service...', ImageForm.user);
   //  console.log(ImageForm.bookName);
   //  console.log(ImageForm.bookPrice);
   //  console.log(ImageForm.selltype);
   //  console.log(ImageForm.user);
   //  console.log(ImageForm);
   //  console.log(formData.get('user'));

    return this.httpClient.post('CampusCentricSHX/webapi/myresource/registerBook/',formData);
  }
  postFile1(ImageForm:any,filetoUpload: File){
    const formData: FormData = new FormData();
   
    formData.append('sName',ImageForm.sName);
    formData.append('emailId',ImageForm.emailId);
    formData.append('qrScan',filetoUpload,filetoUpload.name);
    formData.append('mobile',ImageForm.mobile);
    formData.append('password',ImageForm.password);

   console.log('Inside Service...', ImageForm.user);
   //  console.log(ImageForm.bookName);
   //  console.log(ImageForm.bookPrice);
   //  console.log(ImageForm.selltype);
   //  console.log(ImageForm.user);
   //  console.log(ImageForm);
   //  console.log(formData.get('user'));

    return this.httpClient.post('CampusCentricSHX/webapi/myresource/registerStudent/',formData);
  }
  registerStudent1(student: any) {
    console.log(student);
    return this.httpClient.post('CampusCentricSHX/webapi/myresource/registerStudent1/', student);
   }
  postProduct(ImageForm:any,filetoUpload: File,student: any){
    const formData: FormData = new FormData();
   
    formData.append('productName',ImageForm.productName);
    formData.append('categoryName',ImageForm.categoryName);
    formData.append('productImage',filetoUpload,filetoUpload.name);
    formData.append('productPrice',ImageForm.productPrice);
    formData.append('studentId',student.studentId);

   console.log('Inside Service...', ImageForm.user);
   //  console.log(ImageForm.bookName);
   //  console.log(ImageForm.bookPrice);
   //  console.log(ImageForm.selltype);
   //  console.log(ImageForm.user);
   //  console.log(ImageForm);
   //  console.log(formData.get('user'));

    return this.httpClient.post('CampusCentricSHX/webapi/myresource/registerProduct/',formData);
  }
  getBooks(){
    return this.httpClient.get('CampusCentricSHX/webapi/myresource/getBooks');
  }
  getDaily(){
    return this.httpClient.get('CampusCentricSHX/webapi/myresource/getDaily');
  }
  getElectronic(){
    return this.httpClient.get('CampusCentricSHX/webapi/myresource/getElectronic');
  }

  mail(emailId : any,subject: any, body : any){
    return this.httpClient.get('CampusCentricSHX/webapi/myresource/mail/'+ emailId + '/' + subject + '/' + body );
  }

}
