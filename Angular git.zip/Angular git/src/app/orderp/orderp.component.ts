import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CampusshxService } from '../campusshx.service';


@Component({
  selector: 'app-orderp',
  templateUrl: './orderp.component.html',
  styleUrls: ['./orderp.component.css'],
})
export class OrderpComponent implements OnInit {
  product : any; products: any;studentId : any;type1:any;
  flag : any;flag1 : any;emailId: any;li = [];oproduct : any;
  product1: any; productPrice : any;subject : any; body : any;
  productId : any; oproduct1 : any;productStatus:any;rstudentId:any;
  
  constructor(private router: Router,private service:CampusshxService) {
    this.product = localStorage.getItem("Products");
    this.studentId = localStorage.getItem('studentId');
  }

  ngOnInit(): void {
    this.service.getProductByName(this.product, this.studentId).subscribe((result: any) => {console.log(result); this.products = result;this.product1 = this.products[0];
    this.flag = 1});
  }

  
  price(value : any){
    this.li = value.split(",");
    this.productPrice = this.li[0];
    this.productId = this.li[1];
    localStorage.setItem('productPrice',this.li[0]);
    localStorage.setItem('productId',this.li[1]);
    localStorage.setItem('rstudentId',this.studentId);
    localStorage.setItem('productStatus',this.li[3]);
    localStorage.setItem('productName',this.li[4]);
    localStorage.setItem('productImage',this.li[5]);
    console.log(this.li[5]);
    
    
  }

  order(productId : any){
    this.router.navigate(['paymento']);
  }
}
