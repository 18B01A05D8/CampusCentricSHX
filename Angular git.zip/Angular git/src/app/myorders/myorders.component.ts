import { Component, OnInit } from '@angular/core';
import { CampusshxService } from '../campusshx.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-myorders',
  templateUrl: './myorders.component.html',
  styleUrls: ['./myorders.component.css']
})
export class MyordersComponent implements OnInit {
  studentId:any;
  orders:any;
  flag:any;
  constructor(private router:Router,private service: CampusshxService)  {
    this.studentId = localStorage.getItem('studentId');
   }

  ngOnInit(): void {
    this.service.viewOrder(this.studentId).subscribe( (result: any) => {console.log(result); this.orders = result;this.flag = 1; });
  }

}
