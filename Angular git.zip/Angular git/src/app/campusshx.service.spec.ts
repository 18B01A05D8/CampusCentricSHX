import { TestBed } from '@angular/core/testing';

import { CampusshxService } from './campusshx.service';

describe('CampusshxService', () => {
  let service: CampusshxService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CampusshxService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
