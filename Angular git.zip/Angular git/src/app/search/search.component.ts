import { Component, OnInit } from '@angular/core';

import { CampusshxService } from '../campusshx.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  studentId:any;bookName:any;books:any;flag:any;
  productName:any;products:any;flag1:any;
  constructor(private service: CampusshxService, private toastr: ToastrService, private router: Router) {
      this.studentId = localStorage.getItem('studentId');
   }

  ngOnInit(): void {
  }
  Books(){
    this.service.searchBook(this.bookName, this.studentId).subscribe((result:any)=>{console.log(result);
      this.books = result;this.flag = 1;
      })
  }
  Buy(bookName:any) {
    console.log(bookName);
    localStorage.setItem("Books",bookName);
    this.router.navigate(['order']);
}
Products() {
  this.service.searchProduct(this.productName, this.studentId).subscribe((result:any)=>{console.log(result);
    this.products = result;this.flag1 = 1;
    })
}
Buy1(productName:any) {
  console.log(productName);
  localStorage.setItem("Products",productName);
  this.router.navigate(['orderp']);
}

}
