import { Component, OnInit } from '@angular/core';
import { CampusshxService } from '../campusshx.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-show-books',
  templateUrl: './show-books.component.html',
  styleUrls: ['./show-books.component.css']
})
export class ShowBooksComponent implements OnInit {
  books: any;
  retrivedData : any;
  bookName : any;
  constructor(private router:Router,private service: CampusshxService) {
   }

  ngOnInit(): void {
    this.service.getBooks().subscribe( (result: any) => {console.log(result); this.books = result; });
  }

  Buy(bookName:any) {
    console.log(bookName);
    localStorage.setItem("Books",bookName);
    this.router.navigate(['order']);
}

}


