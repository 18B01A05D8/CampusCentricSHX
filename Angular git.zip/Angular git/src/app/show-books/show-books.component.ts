import { Component, OnInit } from '@angular/core';
import { CampusshxService } from '../campusshx.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-show-books',
  templateUrl: './show-books.component.html',
  styleUrls: ['./show-books.component.css']
})
export class ShowBooksComponent implements OnInit {
  books: any;
  retrivedData : any;
  bookName : any;
  studentId:any;
  category:any;
  constructor(private router:Router,private service: CampusshxService) {
    this.studentId = localStorage.getItem('studentId');
    this.category = localStorage.getItem('category');
   }

  ngOnInit(): void {
    console.log(this.category);
    this.service.getBookByCategoryName(this.category, this.studentId).subscribe( (result: any) => {console.log(result); this.books = result; });
  }

  Buy(bookName:any) {
    console.log(bookName);
    localStorage.setItem("Books",bookName);
    this.router.navigate(['order']);
}

}


