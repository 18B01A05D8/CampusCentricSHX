import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { ToastrModule } from 'ngx-toastr';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { RegisterComponent } from './register/register.component';
import { BookComponent } from './book/book.component';
import { ProductComponent } from './product/product.component';
import { HeaderComponent } from './header/header.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ShowBooksComponent } from './show-books/show-books.component';
import { ShowElectronicComponent } from './show-electronic/show-electronic.component';
import { ShowDailyComponent } from './show-daily/show-daily.component';

const routes: Routes = [{path: 'home', component: HomeComponent},
                        {path: 'login', component: LoginComponent},
                        {path: 'book', component: BookComponent},
                        {path: 'product', component: ProductComponent},
                        {path: 'header', component: HeaderComponent},
                        {path: 'register', component: RegisterComponent},
                        {path: 'dashboard', component: DashboardComponent},
                        {path: 'show-books', component: ShowBooksComponent},
                        {path: 'show-electronic', component: ShowElectronicComponent},
                        {path: 'show-daily', component: ShowDailyComponent}
                        
];
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    RegisterComponent,
    BookComponent,
    ProductComponent,
    HeaderComponent,
    DashboardComponent,
    ShowBooksComponent,
    ShowElectronicComponent,
    ShowDailyComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
    BrowserAnimationsModule,
    ToastrModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
