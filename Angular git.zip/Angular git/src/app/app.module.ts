import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { ToastrModule } from 'ngx-toastr';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { RegisterComponent } from './register/register.component';
import { BookComponent } from './book/book.component';
import { ProductComponent } from './product/product.component';
import { HeaderComponent } from './header/header.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ShowBooksComponent } from './show-books/show-books.component';
import { ShowElectronicComponent } from './show-electronic/show-electronic.component';
import { ShowDailyComponent } from './show-daily/show-daily.component';
import { OrderComponent } from './order/order.component';
import { OrderpComponent } from './orderp/orderp.component';
import { CategoryComponent } from './category/category.component';
import { UploadsComponent } from './uploads/uploads.component';
import { PaymentComponent } from './payment/payment.component';
import { PaymentoComponent } from './paymento/paymento.component';
import { MyordersComponent } from './myorders/myorders.component';
import { ProfileComponent } from './profile/profile.component';
import { SearchComponent } from './search/search.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { OtpComponent } from './otp/otp.component';

const routes: Routes = [{path: 'home', component: HomeComponent},
                        {path: 'login', component: LoginComponent},
                        {path: 'book', component: BookComponent},
                        {path: 'product', component: ProductComponent},
                        {path: 'header', component: HeaderComponent},
                        {path: 'register', component: RegisterComponent},
                        {path: 'dashboard', component: DashboardComponent},
                        {path: 'show-books', component: ShowBooksComponent},
                        {path: 'show-electronic', component: ShowElectronicComponent},
                        {path: 'show-daily', component: ShowDailyComponent},
                        {path: 'order', component: OrderComponent},
                        {path: 'orderp', component: OrderpComponent},
                        {path: 'category', component: CategoryComponent},
                        {path: 'uploads', component: UploadsComponent},
                        {path: 'payment', component: PaymentComponent},
                        {path: 'paymento', component: PaymentoComponent},
                        {path: 'myorders', component: MyordersComponent},
                        {path: 'profile', component: ProfileComponent},
                        {path: 'search', component: SearchComponent},
                        {path: 'feedback', component: FeedbackComponent},
                        {path: 'otp', component: OtpComponent},
                        {path: 'forgotpassword', component: ForgotpasswordComponent}
                        
];
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    RegisterComponent,
    BookComponent,
    ProductComponent,
    HeaderComponent,
    DashboardComponent,
    ShowBooksComponent,
    ShowElectronicComponent,
    ShowDailyComponent,
    OrderComponent,
    OrderpComponent,
    CategoryComponent,
    UploadsComponent,
    PaymentComponent,
    PaymentoComponent,
    MyordersComponent,
    ProfileComponent,
    SearchComponent,
    FeedbackComponent,
    ForgotpasswordComponent,
    OtpComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
    BrowserAnimationsModule,
    ToastrModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
