import { Component,NgZone, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CampusshxService } from './../campusshx.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-otp',
  templateUrl: './otp.component.html',
  styleUrls: ['./otp.component.css']
})
export class OtpComponent implements OnInit {
  otp:any;npassword:any;otpNum:any;fpmail:any;
  constructor(private router:Router, private campusshxService: CampusshxService, private toastr: ToastrService) { 
    this.otpNum = localStorage.getItem("otpNum");
    this.fpmail = localStorage.getItem("fpmail");
   }

  ngOnInit(): void {
  }
  resetpassword() {
    console.log(this.otp);
    console.log(this.npassword);
    console.log(this.otpNum);
    if(this.otp == this.otpNum) {
      if(this.npassword.length >= 6) {
        this.campusshxService.updatePassword(this.fpmail, this.npassword).subscribe((result: any) => { console.log(result);} );
        this.toastr.success("Password reset is successful :)");
        this.router.navigate(['login']);
      }
      else 
        alert("Password of to be length 6!!!");
    }
    else alert("Otp entered is invalid :(");
      
  }

}
