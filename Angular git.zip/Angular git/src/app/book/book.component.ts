import { Component, OnInit } from '@angular/core';
import { CampusshxService } from './../campusshx.service';
//import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent implements OnInit {

  imageUrl: string = '';
  fileToUpload: File | null = null;
  reader!: FileReader;
  emailId: any;
  student:any;
  constructor(private service: CampusshxService) {
    //this.imageUrl = '/assets/img/default-image.png';
    this.emailId = localStorage.getItem("email");
    
  }
  ngOnInit(){
    this.student = JSON.parse(localStorage.getItem("student") || '{}');
  }
  showToaster(){
      //this.toastr.success("Book Uploaded Successfully!!!!")
      alert("Book Uploaded Successfully!!!!")
  }
  
  handleFileInput(file: FileList){
    this.fileToUpload = file.item(0);
    this.reader = new FileReader();
    if(this.fileToUpload) {
      this.reader.readAsDataURL(this.fileToUpload);
    }
    this.reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };
  }
  OnSubmit(imageForm: any) {
        //console.log('in book.ts User ');
        //console.log(this.user);
        console.log('in book.ts Bookinform:');
        console.log(imageForm);

    if(this.fileToUpload) {    
    this.service.postFile(imageForm, this.fileToUpload, this.student).subscribe (
      data => {
        //this.imageUrl = '/assets/Images/recipe.jpg';
        console.log('done');
      }
    );
    }
  }
}
