import { Component, OnInit } from '@angular/core';
import { CampusshxService } from './../campusshx.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent implements OnInit {
  categories:any;
  imageUrl: string = '';
  fileToUpload: File | null = null;
  reader!: FileReader;
  emailId: any;
  student:any;
  li:any;
  flag:any;
  category:any;
  constructor(private service: CampusshxService, private toastr: ToastrService, private router: Router) {
    //this.imageUrl = '/assets/img/default-image.png';
    this.emailId = localStorage.getItem("email");
    
  }
  ngOnInit(){
    this.service.getCategory().subscribe( (result: any) => {console.log(result); this.categories = result;})
    console.log(this.categories);
    this.student = JSON.parse(localStorage.getItem("student") || '{}');
  }
  Category(type : any){
    if(type == 'Other')  this.flag = 1;
    else {
      console.log(type);
      this.category = type;
    }
    
  }
  
  
  handleFileInput(file: FileList){
    this.fileToUpload = file.item(0);
    this.reader = new FileReader();
    if(this.fileToUpload) {
      this.reader.readAsDataURL(this.fileToUpload);
    }
    this.reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };
  }
  OnSubmit(imageForm: any) {
        //console.log('in book.ts User ');
        //console.log(this.user);
        if(this.flag != 1) imageForm.categoryName = this.category;
        console.log('in book.ts Bookinform:');
        console.log(imageForm);

    if(this.fileToUpload) {    
    this.service.postFile(imageForm, this.fileToUpload, this.student).subscribe (
      data => {
        //this.imageUrl = '/assets/Images/recipe.jpg';
        console.log('done');
        this.toastr.success("Book Uploaded Successfully!!!!")
      this.router.navigate(['dashboard']);
      }
    );
    }
  }
}
