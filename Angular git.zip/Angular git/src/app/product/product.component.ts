import { Component, OnInit } from '@angular/core';
import { CampusshxService } from './../campusshx.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  imageUrl: string = '';
  fileToUpload: File | null = null;
  reader!: FileReader;
  emailId: any;
  student:any;
  category:any;
  constructor(private service: CampusshxService, private toastr: ToastrService, private router: Router) {
    //this.imageUrl = '/assets/img/default-image.png';
    this.emailId = localStorage.getItem("email");
    
  }
  ngOnInit(){
    this.student = JSON.parse(localStorage.getItem("student") || '{}');
  }
  Category(type : any){
    
      console.log(type);
      this.category = type;
    
  }
  
  
  handleFileInput(file: FileList){
    this.fileToUpload = file.item(0);
    this.reader = new FileReader();
    if(this.fileToUpload) {
      this.reader.readAsDataURL(this.fileToUpload);
    }
    this.reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };
  }
  OnSubmit(imageForm: any) {
        //console.log('in product.ts User ');
        //console.log(this.user);
        console.log('in product.ts Productinform:');
        imageForm.categoryName = this.category;
        console.log(imageForm);

    if(this.fileToUpload) {    
    this.service.postProduct(imageForm, this.fileToUpload, this.student).subscribe (
      data => {
        //this.imageUrl = '/assets/Images/recipe.jpg';
        console.log('done');
        this.toastr.success("Product Uploaded Successfully!!!!");
    this.router.navigate(['dashboard']);
      }
    );
    }
  }
}
