import { Component,NgZone, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CampusshxService } from './../campusshx.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {
  mails:any;emailId:any;mflag:any;randomNum:any;
  subject:any;body:any;
  constructor(private router:Router, private campusshxService: CampusshxService, private toastr: ToastrService) {  }

  ngOnInit(): void {
    this.campusshxService.getMails().subscribe( (result: any) => {console.log(result); this.mails = result;})
  }
  forgotpassword() {
    this.mflag = this.mails.includes(this.emailId);
    if(this.mflag == true) {
      this.randomNum = Math.floor(Math.random() * (9999 - 1000 + 1)) + 1000; 
      this.subject = "CampusCentricSecondHandExchange Forgot Password";
    this.body = "OTP to reset your password is " + this.randomNum;
      localStorage.setItem("otpNum", this.randomNum);
      localStorage.setItem("fpmail", this.emailId);
      this.toastr.success("Sent code to mail");
      this.router.navigate(['otp']);
    }
    else alert("Entered mail is not registerd!!");
      
  }
}
