import { Component,NgZone, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ViewChild,ElementRef } from '@angular/core';
import { catchError, } from 'rxjs/operators';
import { CampusshxService } from './../campusshx.service';
import { NgModule } from '@angular/core';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  auth2:any;
  student: any;
  retrivedData: any;

  constructor(private router:Router, private campusshxService: CampusshxService, private toastr: ToastrService) {
    this.student = {emailId: '', password: ''};
   }

  ngOnInit(): void {
  }
  login() {
    this.campusshxService.getUserByEmail(this.student).subscribe((result: any) => {console.log(result); this.retrivedData = result;
      //console.log(this.retrivedData.password);
      if(result == null) {
        console.log("Invalid Credentials");
        alert("Invalid Credentials");
      }
      else {
        //let decrypted_pass = this.DeCryptpassword(this.retrivedData.password);
        console.log(this.retrivedData.password);
        if(this.student.password != this.retrivedData.password ||this.retrivedData == null){
          console.log("Invalid Credentials");
          alert("Invalid Credentials");
        }
        else{
          this.campusshxService.setUserLoggedIn();
          this.toastr.success("Logged in successfully :)")
          this.router.navigate(['dashboard']);
        }
        localStorage.setItem('name',this.retrivedData.sName);
        localStorage.setItem("email",this.retrivedData.emailId);
        localStorage.setItem('studentId', this.retrivedData.studentId);
        localStorage.setItem('student', JSON.stringify(this.retrivedData));
      }    
      
    });
  }
  

}
