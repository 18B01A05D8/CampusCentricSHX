import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CampusshxService } from '../campusshx.service';


@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css'],
})
export class OrderComponent implements OnInit {
  book : any; books: any;books1: any;studentId : any;type1:any;
  flag : any;flag1 : any;emailId: any;li = [];obook : any;
  book1: any; bookPrice : any;subject : any; body : any;
  bookId : any; obook1 : any;bookStatus:any;rstudentId:any;
  rstudent:any;
  
  constructor(private router: Router,private service:CampusshxService) {
    this.book = localStorage.getItem("Books");
    this.studentId = localStorage.getItem('studentId');
  }

  ngOnInit(): void {
    this.service.getBookByName(this.book, this.studentId).subscribe( (result: any) => {console.log(result); this.books = result;this.book1 = this.books[0];
    this.flag = 1});
  }

  
  price(value : any){
    this.li = value.split(",");
    console.log(this.li[0]);
    this.bookPrice = this.li[0];
    this.bookId = this.li[1];
    this.rstudentId = this.li[2];
    localStorage.setItem('bookPrice',this.li[0]);
    localStorage.setItem('bookId',this.li[1]);
    localStorage.setItem('rstudentId',this.rstudentId);
    localStorage.setItem('bookStatus',this.li[3]);
    localStorage.setItem('bookName',this.li[4]);
    localStorage.setItem('bookImage', this.li[5]);
    
    
  }

  order(bookId : any){
    this.router.navigate(['payment']);
  }
}
