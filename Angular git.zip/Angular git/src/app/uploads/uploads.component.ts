import { Component, OnInit } from '@angular/core';
import { CampusshxService } from './../campusshx.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';


@Component({
  selector: 'app-uploads',
  templateUrl: './uploads.component.html',
  styleUrls: ['./uploads.component.css']
})
export class UploadsComponent implements OnInit {
  studentId : any;
  books:any;
  products:any;
  constructor(private service: CampusshxService, private toastr: ToastrService, private router: Router) { 
    this.studentId = localStorage.getItem("studentId");
  }

  ngOnInit(): void {
    this.service.getAllBooks(this.studentId).subscribe( (result: any) => {console.log(result); this.books = result; });
    this.service.getAllProducts(this.studentId).subscribe( (result: any) => {console.log(result); this.products = result; });
  }

}
