import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CampusshxService } from '../campusshx.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
  flag:any;flag1:any;rstudentId:any;order:any;student:any;
  bookPrice:any;bookId:any;bookName:any;bookImage:any;
  bookStatus:any;rstudent:any;subject:any;subject1:any;
  body:any;body1:any;paymenttype:any;qrScan:any;
  ostudent:any;productId:any;orderPayment : any;
  rating:any;review:any;
  constructor(private router : Router, private service:CampusshxService, private toastr: ToastrService) {
    this.student = JSON.parse(localStorage.getItem("student") || '{}');
    this.bookPrice = localStorage.getItem('bookPrice');
    this.bookId = localStorage.getItem('bookId');
    this.rstudentId = localStorage.getItem('rstudentId');
    this.bookStatus = localStorage.getItem('bookStatus');
    this.bookName = localStorage.getItem('bookName');
    this.bookImage = localStorage.getItem('bookImage');
    console.log(this.bookImage);
   }

  ngOnInit(): void {
    this.service.getStudent(this.rstudentId).subscribe( (result: any) => {console.log(result); this.rstudent = result; this.flag1 = 1;})
    this.qrScan = this.rstudent.qrScan;

   }

  Payment(type : any){
    console.log(this.rstudent.qrScan);
    if(this.rstudent.qrScan == "Offline Payment") {
      console.log("In Payment.ts - 1");
       this.flag = 0;
       this.paymenttype = "Offline";
    }
    else if(type == 'online') {
      console.log("In Payment.ts - 2");
       this.flag = 1;
       this.paymenttype = "Online";
    }
    else {
      console.log("In Payment.ts - 3");
      this.flag = 0;
      this.paymenttype = "Offline";
    }  
  }
  showToaster() {
    console.log(this.rstudent.sName);
    console.log(this.student.sName);
      this.subject = "Order Request Accepted";
    this.body = "Hi "+this.student.sName+"\nYour order for the book "+ this.bookName+" is successfull, the order is being shipped "+" \n Price of the book: "+this.bookPrice;
     this.service.mail(this.student.emailId,this.subject,this.body).subscribe();
   
      this.subject1 = "Order Placed for your uploads";
      this.body1 = "Hi "+this.rstudent.sName+"\nOrder is placed for the book "+ this.bookName+" by the user "+ this.student.sName+" \n Price of the book: "+this.bookPrice + "\nPayment is done through: " + this.paymenttype+ "\nMobile number of buyer is : " + this.student.mobile;
      this.service.mail(this.rstudent.emailId,this.subject1,this.body1).subscribe();

      this.bookStatus = "Sold";
      this.service.updateBook(this.bookId,this.bookStatus).subscribe((result: any) => { console.log(result); 
        ;} );
      
      console.log('In payment.ts');
      this.productId = 0;
      this.orderPayment = this.paymenttype;
      this.service.registerOrder(this.bookId, this.student.studentId, this.productId, this.orderPayment).subscribe((result: any) => { console.log(result); 
        ;} );
        this.toastr.success("Order Placed Successfully");
        setTimeout(() => { this.router.navigate(['dashboard']); }, 2000);
        

  }
  
  

}
