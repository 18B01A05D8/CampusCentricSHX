import { Component, OnInit } from '@angular/core';
import { CampusshxService } from '../campusshx.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-show-daily',
  templateUrl: './show-daily.component.html',
  styleUrls: ['./show-daily.component.css']
})
export class ShowDailyComponent implements OnInit {
  products: any;
  retrivedData : any;
  productName : any;
  studentId:any;
  constructor(private router:Router,private service: CampusshxService) {
    this.studentId = localStorage.getItem('studentId');
   }

  ngOnInit(): void {
    this.service.getDaily(this.studentId).subscribe( (result: any) => {console.log(result); this.products = result; });
  }

  Buy(productName:any) {
    console.log(productName);
    localStorage.setItem("Products",productName);
    this.router.navigate(['orderp']);
}

}
