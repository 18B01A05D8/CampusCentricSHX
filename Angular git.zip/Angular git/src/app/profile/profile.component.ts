import { Component, OnInit } from '@angular/core';
import { CampusshxService } from '../campusshx.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  student1:any;student:any;studentId : any;
  sName : any; mobile : any;flag : any;emailId:any;
  password:any;password1:any;new:any = 0;
  constructor(private service: CampusshxService, private toastr: ToastrService, private router: Router) {
    //this.user = JSON.parse(localStorage.getItem('user'));
    
   }

  ngOnInit(): void {
    
    this.studentId = localStorage.getItem('studentId');
    console.log(this.studentId);
    this.service.getStudent(this.studentId).subscribe( (result: any) => {console.log(result); this.student = result;});

  }
  
  pass(password2 : any){
    console.log(password2);
    if(password2 == this.student.password){
      this.new = 1
    }
    else{
      alert("Current Password is wrong");
    }
  }

  update(){
    console.log(this.emailId);
    console.log(this.sName);
    console.log(this.mobile);
    console.log(this.student);
    if(this.student.emailId != this.emailId) 
      this.service.updateEmail(this.student.studentId, this.student.emailId).subscribe((result: any) => { console.log(result);} );
    if(this.student.sName != this.sName) {
      console.log('in name');
      this.service.updateName(this.student.studentId, this.student.sName).subscribe((result: any) => { console.log(result);} );
    }
    if(this.student.mobile != this.mobile)
      this.service.updateMobile(this.student.studentId, this.student.mobile).subscribe((result: any) => { console.log(result);} );
    if(this.new == 1) 
    this.service.updatePassword(this.student.studentId, this.password1).subscribe((result: any) => { console.log(result);} );

    this.toastr.success("Updated Successfully!!!!");
    this.router.navigate(['dashboard']);

  }
  
  
  
}
