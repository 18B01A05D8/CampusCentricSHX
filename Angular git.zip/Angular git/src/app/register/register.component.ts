import { Component, OnInit } from '@angular/core';
import { CampusshxService } from './../campusshx.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
 flag:any = 0;
  student:any;
  subject: String;
  body: String;
  imageUrl: string = '';
  fileToUpload: File | null = null;
  reader!: FileReader;
  emailId: any;
  flag1:any=0;
  mails:any;mflag:any;vflag:any;phone:any;
  constructor(private service: CampusshxService,private toastr: ToastrService, private router: Router) {
    this.student = {studentId: '', sName: '', mobile: '', emailId: '', password:'', qrScan:''};
    this.subject = "CampusCentricSecondHandExchange Registration";
    this.body = "Thank you for registering to CampusCentricSecondHandExchange. We hope you will enjoy our services";

   }

  ngOnInit(): void {
    this.service.getMails().subscribe( (result: any) => {console.log(result); this.mails = result;})
  }
  Students(type : any){
    if(type == 'online')  this.flag = 1;
    else {
      this.student.qrScan = "Offline Payment";
    }
    
  }
  handleFileInput(file: FileList){
    this.fileToUpload = file.item(0);
    this.reader = new FileReader();
    if(this.fileToUpload) {
      this.reader.readAsDataURL(this.fileToUpload);
    }
    this.reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };
  }
  OnSubmit(imageForm: any) {
       this.flag1 = 0;
        console.log('in register.ts Bookinform:');
        console.log(imageForm);
        this.phone = this.student.mobile.toString();
        console.log(this.mails.includes(this.student.emailId));
        this.mflag = this.mails.includes(this.student.emailId);
        let regex = new RegExp('[a-z0-9]+@[a-z]+\.[a-z]{2,3}'); 
        console.log(regex.test(this.student.emailId));
        this.vflag = regex.test(this.student.emailId);

        if(this.student.sName == "" || this.student.sName == null) {
          alert("Name to be entered!!");
          this.flag1 = 1;
        }
        else if(this.mflag == true) {
          alert("Entered mailId is already registered!!");
          this.flag1 = 1;
        }
        else if(this.vflag == false) {
          alert("Enter valid Email");
          this.flag1 = 1;
        } 
        else if(this.student.password.length < 6) {
          alert("Password of to be length 6!!!");
          this.flag1 = 1;
        }
        else if(this.phone.length != 10) {
          console.log(this.phone.length);
          console.log(this.phone);
          alert("Enter valid mobile number");
          this.flag1 = 1;
        }
        if(this.flag1 == 0) {

    if(this.fileToUpload) {    
    this.service.postFile1(imageForm, this.fileToUpload).subscribe (
      data => {
        //this.imageUrl = '/assets/Images/recipe.jpg';
        console.log('done');
        this.toastr.success("Got Resitered!!!")
    this.router.navigate(['login']);
        this.service.mail(this.student.emailId,this.subject,this.body).subscribe();
      }
    );
    }
    else {
      this.service.registerStudent1(this.student).subscribe((result: any) => { console.log(result); 
        ;} );
        this.service.mail(this.student.emailId,this.subject,this.body).subscribe();
        this.toastr.success("Got Resitered!!!")
    this.router.navigate(['login']);
    }
  }
  }
  
}
