import { Component, OnInit } from '@angular/core';
import { CampusshxService } from './../campusshx.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
 flag:any = 0;
  student:any;
  subject: String;
  body: String;
  imageUrl: string = '';
  fileToUpload: File | null = null;
  reader!: FileReader;
  emailId: any;
  constructor(private service: CampusshxService,private toastr: ToastrService, private router: Router) {
    this.student = {studentId: '', sName: '', mobile: '', emailId: '', password:'', qrScan:''};
    this.subject = "CampusCentricSecondHandExchange Registration";
    this.body = "Thank you for registering to CampusCentricSecondHandExchange. We hope you will enjoy our services";
   }

  ngOnInit(): void {
  }
  Students(type : any){
    if(type == 'online')  this.flag = 1;
    else {
      this.student.qrScan = "Offline Payment";
    }
    
  }
  handleFileInput(file: FileList){
    this.fileToUpload = file.item(0);
    this.reader = new FileReader();
    if(this.fileToUpload) {
      this.reader.readAsDataURL(this.fileToUpload);
    }
    this.reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };
  }
  OnSubmit(imageForm: any) {
        //console.log('in book.ts User ');
        //console.log(this.user);
        console.log('in register.ts Bookinform:');
        console.log(imageForm);

    if(this.fileToUpload) {    
    this.service.postFile1(imageForm, this.fileToUpload).subscribe (
      data => {
        //this.imageUrl = '/assets/Images/recipe.jpg';
        console.log('done');
        this.toastr.success("Got Resitered!!!")
    this.router.navigate(['login']);
        this.service.mail(this.student.emailId,this.subject,this.body).subscribe();
      }
    );
    }
    else {
      this.service.registerStudent1(this.student).subscribe((result: any) => { console.log(result); 
        ;} );
        this.service.mail(this.student.emailId,this.subject,this.body).subscribe();
        this.toastr.success("Got Resitered!!!")
    this.router.navigate(['login']);
    }
  }
  
}
