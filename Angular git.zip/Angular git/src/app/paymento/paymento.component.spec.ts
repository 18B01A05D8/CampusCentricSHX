import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentoComponent } from './paymento.component';

describe('PaymentoComponent', () => {
  let component: PaymentoComponent;
  let fixture: ComponentFixture<PaymentoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PaymentoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
