import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CampusshxService } from '../campusshx.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-paymento',
  templateUrl: './paymento.component.html',
  styleUrls: ['./paymento.component.css']
})
export class PaymentoComponent implements OnInit {
  flag:any;flag1:any;
  rstudentId:any;
  order:any;
  student:any;
  productPrice:any;
  productId:any;
  productName:any;
  productImage:any;
  productStatus:any;
  rstudent:any;
  subject:any;subject1:any;
  body:any;body1:any;
  paymenttype:any;
  qrScan:any;
  ostudent:any;
  bookId:any;
  orderPayment : any;
  constructor(private router : Router, private service:CampusshxService, private toastr: ToastrService) {
    this.student = JSON.parse(localStorage.getItem("student") || '{}');
    this.productPrice = localStorage.getItem('productPrice');
    this.productId = localStorage.getItem('productId');
    this.rstudentId = localStorage.getItem('rstudentId');
    this.productStatus = localStorage.getItem('productStatus');
    this.productName = localStorage.getItem('productName');
    this.productImage = localStorage.getItem('productImage');
    this.productImage =this.productImage.slice(1);
    console.log(this.productImage);
   }

  ngOnInit(): void {
    this.service.getStudent(this.rstudentId).subscribe( (result: any) => {console.log(result); this.rstudent = result; this.flag1 = 1;})
    this.qrScan = this.rstudent.qrScan;
   }

  Payment(type : any){
    console.log(this.rstudent.qrScan);
    if(this.rstudent.qrScan == "Offline Payment") {
      console.log("In Payment.ts - 1");
       this.flag = 0;
       this.paymenttype = "Offline";
    }
    else if(type == 'online') {
      console.log("In Payment.ts - 2");
       this.flag = 1;
       this.paymenttype = "Offline";
    }
    else {
      console.log("In Payment.ts - 3");
      this.flag = 0;
      this.paymenttype = "Offline";
    }  
  }
  showToaster() {
    console.log(this.rstudent.sName);
    console.log(this.student.sName);
      this.subject = "Order Request Accepted";
    this.body = "Hi "+this.student.sName+"\nYour order for the product "+ this.productName+" is successfull, the order is being shipped "+" \n Price of the product: "+this.productPrice;
     // this.service.mail(this.student.emailId,this.subject,this.body).subscribe();
   
      this.subject1 = "Order Placed for your uploads";
      this.body1 = "Hi "+this.rstudent.sName+"\nOrder is placed for the product "+ this.productName+" by the user "+ this.student.sName+" \n Price of the product: "+this.productPrice + "\nPayment is done through: " + this.paymenttype;
      //this.service.mail(this.rstudent.emailId,this.subject1,this.body1).subscribe();

      this.productStatus = "Sold";
      this.service.updateProduct(this.productId,this.productStatus).subscribe((result: any) => { console.log(result); 
        ;} );
      
      console.log('In payment.ts');
      this.bookId = 0;
      this.orderPayment = this.paymenttype;
      this.service.registerOrder(this.bookId, this.student.studentId, this.productId, this.orderPayment).subscribe((result: any) => { console.log(result); 
        ;} );
        this.toastr.success("Order Placed Successfully");
        setTimeout(() => { this.router.navigate(['dashboard']); }, 2000);

  }
  

}
