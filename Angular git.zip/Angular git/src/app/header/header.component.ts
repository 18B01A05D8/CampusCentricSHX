import { Component, OnInit } from '@angular/core';
import { CampusshxService } from '../campusshx.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  books = [];
  student:any;
  constructor(public service: CampusshxService) {
    this.student = localStorage.getItem("sName");
   }

  ngOnInit(): void {
    //this.service.getForCart().subscribe(result => this.books.push(result));
  }

  logout(){
    localStorage.clear();
    this.service.setUserLoggedOut();
  }
}
