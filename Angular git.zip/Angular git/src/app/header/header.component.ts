import { Component, OnInit } from '@angular/core';
import { CampusshxService } from '../campusshx.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  books = [];
  student:any;
  constructor(public service: CampusshxService, private router: Router) {
    this.student = localStorage.getItem("sName");
   }

  ngOnInit(): void {
    //this.service.getForCart().subscribe(result => this.books.push(result));
  }

  logout(){
    localStorage.clear();
    this.service.setUserLoggedOut();
  }
  Selectlink(type : any){
    if(type == 'myorders')  this.router.navigate(['myorders']);
    else if(type == 'profile')  this.router.navigate(['profile']);
    else if(type == 'uploads')  this.router.navigate(['uploads']);
    else if(type == 'register')  this.router.navigate(['register']);
    else if(type == 'feedback')  this.router.navigate(['feedback']);
    else if(type == 'logout') {
      localStorage.clear();
    this.service.setUserLoggedOut();
    this.router.navigate(['login']);
    }
    
  }
}
