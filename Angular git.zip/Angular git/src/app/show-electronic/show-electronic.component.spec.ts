import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowElectronicComponent } from './show-electronic.component';

describe('ShowElectronicComponent', () => {
  let component: ShowElectronicComponent;
  let fixture: ComponentFixture<ShowElectronicComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowElectronicComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowElectronicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
