import { Component, OnInit } from '@angular/core';
import { CampusshxService } from '../campusshx.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-show-electronic',
  templateUrl: './show-electronic.component.html',
  styleUrls: ['./show-electronic.component.css']
})
export class ShowElectronicComponent implements OnInit {
  products: any;
  retrivedData : any;
  productName : any;
  constructor(private router:Router,private service: CampusshxService) {
   }

  ngOnInit(): void {
    this.service.getElectronic().subscribe( (result: any) => {console.log(result); this.products = result; });
  }

  Buy(productName:any) {
    console.log(productName);
    localStorage.setItem("Products",productName);
    this.router.navigate(['order']);
}

}
